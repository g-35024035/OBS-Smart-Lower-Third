**OBS 33.0.3 users: read [BUILD-OBS-33-WINDOWS.md](BUILD-OBS-33-WINDOWS.md) first.**

# OBS Smart Lower Third Manager — native OBS plugin (Windows x64)

**Status: source project / pre-release, not a compiled or OBS-tested installer.**

## Features
- Native Qt dock embedded into OBS, CSV import (UTF-8, `name,subtitle` or `nama,kelas`), search and select a name
- PREV / NEXT / PAPAR / SOROK, optional auto-hide
- Three design presets: Modern Gradient, Elegant Gold, Minimal Clean
- Accent color, event title, font, font size, position
- Preview text, last selection and settings persisted via QSettings
- Creates a reusable OBS Browser Source named `Smart Lower Third` using locally generated HTML; transparent 1920x1080 output
- No Firebase, cloud account or internet connection required

## Important limitations of v1.0
- The built-in dock preview is **text-only**, not a live rendered image of the lower third.
- The dock creates the OBS source, but **you must add that existing source to each OBS scene** you wish to use.
- The source refreshes by alternating two local HTML filenames, triggering a browser source reload. Depending on OBS Browser Source versions, you may need to manually press **Refresh cache of current page** if updates do not appear.
- Animations use CSS fade/slide on browser page load. They are not frame-synchronized with OBS transitions.
- CSV is parsed in UTF-8; no XLSX import. The first column is the name if no header exists.
- On-air visibility is not persisted between OBS sessions (starts hidden).
- The plugin must be built against an OBS SDK/build compatible with the target OBS version. OBS 33.0.3 compatibility is **not yet verified**.

## Build prerequisites
1. Windows 10/11 64-bit.
2. OBS Studio 33.0.3 x64, with Browser Source enabled (target version; not yet tested).
3. Visual Studio 2022, **Desktop development with C++** workload.
4. CMake 3.28+ and Ninja.
5. OBS Studio development dependencies (`libobs` and `obs-frontend-api`) and matching Qt 6 Widgets development libraries. Prefer the official OBS plugin-template / OBS build environment for dependency setup. The CMake targets in this project are `OBS::libobs` and `OBS::obs-frontend-api`; adjust target aliases if your SDK exports different names.

## Build from a configured OBS SDK environment
In **x64 Native Tools Command Prompt for VS 2022**, with the OBS and Qt CMake package paths configured:

```powershell
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="C:/path/to/obs-sdk;C:/Qt/6.x/msvc2022_64"
cmake --build build --config Release
cmake --install build --prefix "C:/path/to/staging"
```

The resulting DLL is `obs-smart-lower-third.dll` (or under `build/` depending on generator). Qt and OBS dependencies must be discoverable at runtime; use the Qt version compatible with OBS. **Do not copy arbitrary Qt DLLs over OBS's own Qt DLLs.**

## Manual installation
1. Close OBS.
2. Copy the compiled DLL into the matching OBS installation's `obs-plugins/64bit` directory (or package it in the OBS user plugin directory with the correct layout).
3. Restart OBS. Open **Docks → Smart Lower Third Manager**.
4. Click **IMPORT CSV** and choose an example CSV.
5. Click **CREATE / REPAIR OBS LOWER THIRD SOURCE**.
6. Add an **Existing Browser Source** named `Smart Lower Third` to each scene that should show lower thirds. Position it at canvas origin (0,0) with 1920×1080 size. For non-1080p canvases, use OBS Transform → Fit to Screen.
7. Click **PAPAR** and **SOROK** to test. If the source does not refresh, right-click source → Properties → Refresh cache of current page.

## CSV format
```csv
name,subtitle
ANNISA ZUFAYRAH BINTI MOHD ZULFIKA,GRADUAN TAHUN 6
"CIKGU AHMAD, BIN ALI",GURU PENOLONG KANAN
```

## Architecture
- `src/plugin.cpp`: OBS plugin entry point, Qt dock, CSV parser, QSettings, OBS Browser Source management, HTML/CSS generator.
- `examples/*.csv`: sample data.
- Generated graphics: `%APPDATA%`-style Qt application data path, subfolder `smart-lower-third`, two alternating HTML files.

## Troubleshooting
- **Dock missing:** check OBS log for `Smart Lower Third Manager loaded`; check plugin DLL architecture and matching OBS/Qt ABI.
- **Source creation fails:** install OBS with Browser Source.
- **Graphic invisible:** confirm source exists in current scene, name matches, and press PAPAR.
- **Names not updating:** right-click Browser Source → Properties → Refresh cache of current page; check generated HTML file permissions.
- **CSV accents wrong:** save CSV as UTF-8.

## Future work
A production-grade v2 should implement a native `obs_source_info` graphics source or local HTTP/WebSocket renderer for reliable incremental updates, scene-independent graphics, full WYSIWYG editor, animations without reload, hotkeys, undo, and multi-controller support.
