#include <obs-module.h>
#include <obs-frontend-api.h>
#include <obs.h>
#include <QApplication>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QComboBox>
#include <QSpinBox>
#include <QCheckBox>
#include <QFileDialog>
#include <QFile>
#include <QDir>
#include <QStandardPaths>
#include <QSettings>
#include <QTextStream>
#include <QMessageBox>
#include <QColorDialog>
#include <QColor>
#include <QTimer>
#include <QUrl>
#include <QUrlQuery>
#include <QGroupBox>
#include <QRegularExpression>
#include <QDesktopServices>
#include <QPointer>
#include <QSignalBlocker>
#include <QFontDatabase>
#include <QPlainTextEdit>
#include <QDialog>
#include <QDialogButtonBox>
#include <QHeaderView>
#include <QTableWidget>
#include <QByteArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QCryptographicHash>
#include <QDateTime>
#include <algorithm>
#include <vector>

OBS_DECLARE_MODULE()
OBS_MODULE_USE_DEFAULT_LOCALE("obs-smart-lower-third", "en-US")
MODULE_EXPORT const char *obs_module_description(void) { return "Smart Lower Third Manager: CSV names, OBS dock and configurable lower thirds"; }

namespace {
struct Entry { QString name, subtitle; };
static QString htmlEscape(QString s) { return s.toHtmlEscaped(); }
static QString jsString(const QString &s) {
  QJsonArray a; a.append(s);
  QString v=QString::fromUtf8(QJsonDocument(a).toJson(QJsonDocument::Compact));
  return v.mid(1,v.size()-2);
}
// RFC4180-ish CSV parser: handles quoted commas, escaped quotes and CRLF, UTF-8 BOM.
static QVector<QStringList> parseCsv(const QString &text) {
  QVector<QStringList> rows; QStringList row; QString cell; bool quoted=false;
  for (int i=0;i<text.size();++i) {
    QChar c=text[i];
    if(c=='"') { if(quoted && i+1<text.size() && text[i+1]=='"'){cell+='"';++i;}else quoted=!quoted; }
    else if(c==',' && !quoted){row<<cell;cell.clear();}
    else if((c=='\n'||c=='\r')&&!quoted){if(c=='\r'&&i+1<text.size()&&text[i+1]=='\n')++i;row<<cell;cell.clear();if(!row.join("").trimmed().isEmpty())rows<<row;row.clear();}
    else cell+=c;
  }
  row<<cell; if(!row.join("").trimmed().isEmpty())rows<<row;
  return rows;
}
static QString dataDir(){QString p=QStandardPaths::writableLocation(QStandardPaths::AppDataLocation)+"/smart-lower-third";QDir().mkpath(p);return p;}
static QString graphicsPath(int slot=0){return dataDir()+QString("/lowerthird-%1.html").arg(slot);}
static QString safeColor(const QString &s){QColor c(s);return c.isValid()?c.name():"#1769dd";}
class Dock final: public QWidget {
  Q_OBJECT
  QVector<Entry> entries;
  int index=0;
  bool visible=false;
  QString color="#1769dd";
  QString csvPath;
  QListWidget *names=nullptr;
  QLabel *status=nullptr,*preview=nullptr,*previous=nullptr,*next=nullptr;
  QLineEdit *search=nullptr,*title=nullptr;
  QComboBox *style=nullptr,*position=nullptr,*font=nullptr;
  QSpinBox *fontSize=nullptr,*duration=nullptr;
  QCheckBox *autoHide=nullptr;
  QTimer hideTimer;
  bool syncing=false;
  int refreshSlot=0;
public:
  Dock(){
    setObjectName("SmartLowerThirdDock");
    setWindowTitle("Smart Lower Third Manager");
    auto *root=new QVBoxLayout(this);
    auto *head=new QLabel("SMART LOWER THIRD MANAGER");head->setStyleSheet("font-weight:700;font-size:15px");root->addWidget(head);
    status=new QLabel("No CSV loaded");root->addWidget(status);
    auto *tools=new QHBoxLayout;
    auto *load=new QPushButton("IMPORT CSV");tools->addWidget(load);
    auto *sample=new QPushButton("CSV FORMAT");tools->addWidget(sample);
    root->addLayout(tools);
    search=new QLineEdit;search->setPlaceholderText("Search name...");root->addWidget(search);
    names=new QListWidget;names->setMinimumHeight(145);root->addWidget(names,1);
    previous=new QLabel("Previous: —");next=new QLabel("Next: —");root->addWidget(previous);root->addWidget(next);
    auto *actions=new QHBoxLayout;
    auto *prevBtn=new QPushButton("◀ PREV"),*nextBtn=new QPushButton("NEXT ▶"),*showBtn=new QPushButton("PAPAR"),*hideBtn=new QPushButton("SOROK");
    actions->addWidget(prevBtn);actions->addWidget(nextBtn);actions->addWidget(showBtn);actions->addWidget(hideBtn);root->addLayout(actions);
    auto *design=new QGroupBox("CUSTOM DESIGN");auto *form=new QFormLayout(design);
    style=new QComboBox;style->addItems({"Modern Gradient","Elegant Gold","Minimal Clean"});form->addRow("Template",style);
    title=new QLineEdit("MAJLIS GRADUASI");form->addRow("Event title",title);
    position=new QComboBox;position->addItems({"Bottom left","Bottom center","Bottom right"});form->addRow("Position",position);
    font=new QComboBox; font->addItems({"Arial","Segoe UI","Montserrat","Georgia","Tahoma"});form->addRow("Font",font);
    fontSize=new QSpinBox;fontSize->setRange(24,100);fontSize->setValue(54);form->addRow("Name size",fontSize);
    auto *pick=new QPushButton("Choose accent color");form->addRow("Accent",pick);
    duration=new QSpinBox;duration->setRange(1,120);duration->setValue(8);duration->setSuffix(" seconds");form->addRow("Auto-hide delay",duration);
    autoHide=new QCheckBox("Auto-hide after showing");form->addRow(autoHide);
    root->addWidget(design);
    preview=new QLabel;preview->setWordWrap(true);preview->setMinimumHeight(72);preview->setStyleSheet("background:#16253b;color:white;padding:12px;border-radius:6px");root->addWidget(preview);
    auto *create=new QPushButton("CREATE / REPAIR OBS LOWER THIRD SOURCE");root->addWidget(create);
    auto *hint=new QLabel("Add the generated browser source to each scene where you want the graphic. 1920 × 1080.");hint->setWordWrap(true);root->addWidget(hint);
    connect(load,&QPushButton::clicked,this,[this]{QString p=QFileDialog::getOpenFileName(this,"Import CSV",QString(),"CSV (*.csv)");if(!p.isEmpty())loadCsv(p);});
    connect(sample,&QPushButton::clicked,this,[this]{QMessageBox::information(this,"CSV format","name,subtitle\\nANNISA ZUFAYRAH,GRADUAN TAHUN 6\\nAISYAH,6 AMANAH\\n\\nSave as UTF-8 CSV. Quoted commas are supported.");});
    connect(search,&QLineEdit::textChanged,this,[this](const QString &s){for(int i=0;i<names->count();++i)names->item(i)->setHidden(!names->item(i)->text().contains(s,Qt::CaseInsensitive));});
    connect(names,&QListWidget::currentRowChanged,this,[this](int i){if(!syncing&&i>=0){index=i;save();refresh();}});
    connect(prevBtn,&QPushButton::clicked,this,[this]{if(index>0){--index;refresh();save();if(visible){publish();if(autoHide->isChecked())hideTimer.start(duration->value()*1000);}}});
    connect(nextBtn,&QPushButton::clicked,this,[this]{if(index+1<entries.size()){++index;refresh();save();if(visible){publish();if(autoHide->isChecked())hideTimer.start(duration->value()*1000);}}});
    connect(showBtn,&QPushButton::clicked,this,[this]{if(entries.isEmpty()){QMessageBox::warning(this,"No names","Import a CSV first.");return;}visible=true;publish();if(autoHide->isChecked())hideTimer.start(duration->value()*1000);});
    connect(hideBtn,&QPushButton::clicked,this,[this]{hideTimer.stop();visible=false;publish();});
    connect(&hideTimer,&QTimer::timeout,this,[this]{hideTimer.stop();visible=false;publish();});hideTimer.setSingleShot(true);
    connect(create,&QPushButton::clicked,this,[this]{createSource();});
    connect(pick,&QPushButton::clicked,this,[this]{QColor c=QColorDialog::getColor(QColor(color),this,"Accent color");if(c.isValid()){color=c.name();changed();}});
    connect(style,QOverload<int>::of(&QComboBox::currentIndexChanged),this,[this]{changed();});
    connect(position,QOverload<int>::of(&QComboBox::currentIndexChanged),this,[this]{changed();});
    connect(font,QOverload<int>::of(&QComboBox::currentIndexChanged),this,[this]{changed();});
    connect(fontSize,QOverload<int>::of(&QSpinBox::valueChanged),this,[this]{changed();});
    connect(duration,QOverload<int>::of(&QSpinBox::valueChanged),this,[this]{save();});
    connect(autoHide,&QCheckBox::toggled,this,[this]{save();});
    connect(title,&QLineEdit::textChanged,this,[this]{changed();});
    restore();refresh();publish();
  }
private:
  void loadCsv(const QString &p){
    QFile f(p);if(!f.open(QIODevice::ReadOnly)){QMessageBox::warning(this,"CSV error",f.errorString());return;}
    QString s=QString::fromUtf8(f.readAll());if(s.startsWith(QChar(0xfeff)))s.remove(0,1);
    auto rows=parseCsv(s);if(rows.isEmpty()){QMessageBox::warning(this,"CSV error","CSV is empty.");return;}
    int nameCol=0,subtitleCol=1,start=0;
    QStringList header=rows[0];for(QString &h:header)h=h.trimmed().toLower();
    int foundName=header.indexOf("name");if(foundName<0)foundName=header.indexOf("nama");
    if(foundName>=0){nameCol=foundName;subtitleCol=header.indexOf("subtitle");if(subtitleCol<0)subtitleCol=header.indexOf("kelas");if(subtitleCol<0)subtitleCol=header.indexOf("category");start=1;}
    QVector<Entry> parsed;
    for(int i=start;i<rows.size();++i){const auto &r=rows[i];QString n=nameCol<r.size()?r[nameCol].trimmed():"";if(n.isEmpty())continue;QString sub=subtitleCol>=0&&subtitleCol<r.size()?r[subtitleCol].trimmed():"";parsed.push_back({n,sub});}
    if(parsed.isEmpty()){QMessageBox::warning(this,"CSV error","No valid names found.");return;}
    entries=parsed;index=0;csvPath=p;syncing=true;names->clear();for(int i=0;i<entries.size();++i)names->addItem(QString::number(i+1)+". "+entries[i].name);syncing=false;search->clear();refresh();save();publish();
  }
  void restore(){
    QSettings s("SKIP1","SmartLowerThirdManager");color=s.value("color","#1769dd").toString();csvPath=s.value("csv").toString();index=s.value("index",0).toInt();
    style->setCurrentIndex(s.value("style",0).toInt());position->setCurrentIndex(s.value("position",0).toInt());font->setCurrentText(s.value("font","Arial").toString());fontSize->setValue(s.value("fontSize",54).toInt());title->setText(s.value("title","MAJLIS GRADUASI").toString());duration->setValue(s.value("duration",8).toInt());autoHide->setChecked(s.value("autoHide",false).toBool());
    if(!csvPath.isEmpty()&&QFile::exists(csvPath)){int old=index;loadCsv(csvPath);index=std::clamp(old,0,std::max(0,int(entries.size())-1));refresh();}
    visible=false;
  }
  void save(){QSettings s("SKIP1","SmartLowerThirdManager");s.setValue("csv",csvPath);s.setValue("index",index);s.setValue("color",color);s.setValue("style",style->currentIndex());s.setValue("position",position->currentIndex());s.setValue("font",font->currentText());s.setValue("fontSize",fontSize->value());s.setValue("title",title->text());s.setValue("duration",duration->value());s.setValue("autoHide",autoHide->isChecked());}
  void changed(){save();refresh();publish();}
  void refresh(){
    index=std::clamp(index,0,std::max(0,int(entries.size())-1));
    syncing=true;if(!entries.isEmpty())names->setCurrentRow(index);syncing=false;
    status->setText(entries.isEmpty()?"No CSV loaded":QString("Name %1 / %2 — %3").arg(index+1).arg(entries.size()).arg(visible?"ON AIR":"HIDDEN"));
    previous->setText("Previous: "+(index>0?entries[index-1].name:"—"));next->setText("Next: "+(index+1<entries.size()?entries[index+1].name:"—"));
    QString n=entries.isEmpty()?"SAMPLE NAME":entries[index].name;
    QString sub=entries.isEmpty()?"GRADUAN TAHUN 6":entries[index].subtitle;
    preview->setText("PREVIEW • "+style->currentText()+"\n"+title->text()+"\n"+n+"\n"+sub);
  }
  QString renderHtml()const{
    QString n=entries.isEmpty()?"":entries[index].name;
    QString sub=entries.isEmpty()?"":entries[index].subtitle;
    QString pos=position->currentIndex()==0?"left:5%;":position->currentIndex()==1?"left:50%;transform:translateX(-50%);":"right:5%;";
    QString theme=style->currentIndex()==1?"gold":style->currentIndex()==2?"minimal":"modern";
    QString accent=style->currentIndex()==1?"#d5ac53":safeColor(color);
    QString background=style->currentIndex()==1?"linear-gradient(105deg,#101015,#40301b)":style->currentIndex()==2?"#f8fafc":QString("linear-gradient(105deg,#101a33,%1)").arg(accent);
    QString foreground=style->currentIndex()==2?"#172033":"#ffffff";
    QString html=QString::fromUtf8(R"HTML(<!doctype html><html><head><meta charset="utf-8"><style>
*{box-sizing:border-box}html,body{width:100%;height:100%;margin:0;background:transparent;overflow:hidden;font-family:FONT,Arial,sans-serif}
#lower{position:absolute;bottom:7%;POS max-width:87%;min-width:35%;color:FG;opacity:0;transform-origin:bottom left;transition:opacity .3s ease,translate .4s ease;translate:0 25px}
#lower.on{opacity:1;translate:0 0}
#bar{background:BG;border-left:9px solid ACCENT;padding:19px 30px 23px;box-shadow:0 12px 35px #0006;border-radius:5px}
#event{font-size:24px;font-weight:700;letter-spacing:2px;opacity:.9;margin-bottom:8px}
#name{font-size:SIZEpx;line-height:1.13;font-weight:800;overflow-wrap:anywhere;text-transform:uppercase}
#subtitle{font-size:27px;margin-top:8px;letter-spacing:1px}
</style></head><body><div id="lower" class="STATE"><div id="bar"><div id="event"></div><div id="name"></div><div id="subtitle"></div></div></div><script>
document.getElementById('event').textContent=EVENT;
document.getElementById('name').textContent=NAME;
document.getElementById('subtitle').textContent=SUBTITLE;
</script></body></html>)HTML");
    html.replace("FONT",font->currentText().replace("'",""));html.replace("POS",pos);html.replace("FG",foreground);html.replace("BG",background);html.replace("ACCENT",accent);html.replace("SIZE",QString::number(fontSize->value()));html.replace("STATE",visible&&!entries.isEmpty()?"on":"");
    html.replace("EVENT",jsString(title->text()));html.replace("NAME",jsString(n));html.replace("SUBTITLE",jsString(sub));return html;
  }
  void publish(){
    refresh();refreshSlot=1-refreshSlot;
    QFile f(graphicsPath(refreshSlot));if(f.open(QIODevice::WriteOnly|QIODevice::Truncate)){f.write(renderHtml().toUtf8());f.close();}
    // Refresh browser source after local HTML is updated; this also resets the animation.
    obs_source_t *source=obs_get_source_by_name("Smart Lower Third");
    if(source){obs_data_t *settings=obs_source_get_settings(source);obs_data_set_bool(settings,"is_local_file",true);obs_data_set_string(settings,"local_file",QDir::toNativeSeparators(graphicsPath(refreshSlot)).toUtf8().constData());obs_data_set_int(settings,"width",1920);obs_data_set_int(settings,"height",1080);obs_source_update(source,settings);obs_data_release(settings);obs_source_release(source);}
  }
  void createSource(){
    publish();obs_source_t *source=obs_get_source_by_name("Smart Lower Third");
    if(!source){obs_data_t *settings=obs_data_create();obs_data_set_bool(settings,"is_local_file",true);obs_data_set_string(settings,"local_file",QDir::toNativeSeparators(graphicsPath(refreshSlot)).toUtf8().constData());obs_data_set_int(settings,"width",1920);obs_data_set_int(settings,"height",1080);
      source=obs_source_create("browser_source","Smart Lower Third",settings,nullptr);obs_data_release(settings);
      if(!source){QMessageBox::warning(this,"Browser source unavailable","OBS Browser Source is missing. Install an OBS build with Browser Source support.");return;}
    }
    obs_source_release(source);
    QMessageBox::information(this,"Source ready","Source 'Smart Lower Third' is ready. In each desired scene, add Existing → Browser → Smart Lower Third. If it is not listed, create a Browser Source named Smart Lower Third and select the local file:\n"+graphicsPath(refreshSlot)+"\nSet width 1920 and height 1080.");
  }
};
static QPointer<Dock> dock;
static void onEvent(enum obs_frontend_event event,void *){
  if(event==OBS_FRONTEND_EVENT_EXIT){dock=nullptr;}
}
}
bool obs_module_load(void){
  auto *widget=new Dock();dock=widget;
  if(!obs_frontend_add_dock_by_id("smart-lower-third-dock","Smart Lower Third Manager",widget)){
    blog(LOG_ERROR,"Could not register Smart Lower Third dock");delete widget;dock=nullptr;return false;
  }
  obs_frontend_add_event_callback(onEvent,nullptr);
  blog(LOG_INFO,"Smart Lower Third Manager loaded");return true;
}
void obs_module_unload(void){obs_frontend_remove_event_callback(onEvent,nullptr);dock=nullptr;}
#include "plugin.moc"
