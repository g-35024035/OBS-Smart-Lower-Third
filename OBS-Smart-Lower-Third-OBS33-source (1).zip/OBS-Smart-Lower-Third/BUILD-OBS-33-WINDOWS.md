# OBS Smart Lower Third Manager — OBS Studio 33.0.3 (Windows x64)

## Status (read first)
This package contains **C++ native plugin source**, not a compiled DLL, MSI, or EXE. The source has **not been compiled or tested against OBS 33.0.3**. OBS 33 may have changed APIs or dependency versions; do not assume compatibility until a clean build and live test pass.

## Build on Windows
1. Install Visual Studio 2022 with **Desktop development with C++**, CMake (>=3.28) and Ninja.
2. Prepare the official OBS Studio 33.0.3 **matching source and build/development dependencies** (including `libobs`, `obs-frontend-api` and the Qt 6 version used by your OBS build). The easiest repeatable approach is to use OBS's official `obs-plugintemplate` development environment and its Windows dependency setup, then migrate this project's `src/plugin.cpp` into that environment.
3. Ensure CMake can resolve `find_package(libobs)`, `find_package(obs-frontend-api)`, `find_package(Qt6 COMPONENTS Widgets Core Gui)` and imported targets `OBS::libobs`, `OBS::obs-frontend-api`. Package/target names may need adaptation to your SDK.
4. Open **x64 Native Tools Command Prompt for VS 2022** and run:

```bat
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="C:/OBS-SDK;C:/Qt/6.x/msvc2022_64"
cmake --build build --config Release
cmake --install build --prefix "%CD%/stage"
```

Replace paths with your actual OBS SDK and matching Qt install. If CMake reports missing packages, fix the development environment rather than copying random DLLs into OBS.

## Install only after successful build
1. Back up OBS settings and **close OBS**.
2. Copy the built `obs-smart-lower-third.dll` into the OBS installation's `obs-plugins/64bit` directory (administrator rights may be needed). Keep any additional required plugin resources in their matching data directory. Do not overwrite OBS or Qt system DLLs.
3. Start OBS and check **Help > Log Files > View Current Log** for the plugin loading message.
4. Open **Docks > Smart Lower Third Manager**. Import CSV.
5. Click **CREATE / REPAIR OBS LOWER THIRD SOURCE**. In the desired scene, use **Sources > + > Browser > Add Existing > Smart Lower Third**. If unavailable, create a new Browser source with that exact name, select the local HTML file displayed in the dock dialog, and set 1920x1080.
6. Test **PAPAR**, **SOROK**, **NEXT**, **PREV**, template changes and scene switching. For 720p or 4K OBS canvases, fit/scale the source.

## Known issues / limits
- OBS 33.0.3 compatibility is **unverified**. Source may require adjustments for SDK/API changes.
- The dock preview is a **textual preview**, not a WYSIWYG graphic preview.
- Browser Source reload is used to refresh the graphic; performance and CSS animation timing are dependent on the OBS Browser Source version.
- Source must be added to scenes where needed; creating a source does not automatically insert it into every scene.
- CSV is UTF-8; recommended columns: `name,subtitle` or `nama,kelas`.
- No Windows installer is included; a working DLL can only be supplied after compilation in a compatible Windows OBS build environment.
